function power = binary_resize(original, watermarked, detection)

    minpower = 0;
    maxpower = 1;
    wpsnrmax = 0;
    
    I = imread(watermarked);
    
    eps = 0.0001;
    lastk = maxpower;
    while(abs(maxpower - minpower) >= eps)
        k = (maxpower + minpower)/2;
        Iatck = test_resize(I, k);
        attacked = 'resize-temp.bmp';
        imwrite(Iatck, attacked);
        
        [contains, wpsnr_val] = detection(original, watermarked, attacked);
        delete(attacked);
        
        if contains == 1
            maxpower = k;
        else
            minpower = k;
            if wpsnrmax < wpsnr_val
                wpsnrmax = wpsnr_val;
                lastk = k;
            end
            
        end
    end
    power = lastk;
    
    fprintf('Resize attack: power=%f, WPSNR=%f\n', power, wpsnr_val);
end