%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Course :  Multimedia Data Security
% Project:  Competition, 5th November
% Team   :  DryMark 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;clc;
start_time = cputime;


outputname = 'lenawat.bmp';  % watermarked image name
inputname = 'lena.bmp'; % original image name

%original image
I    = imread(inputname);
Id   = double(I);

wat_size = 32;

% load original watermark
Io = load('drymark.mat').w;



%define watermark strength
%alpha = 0.02035;
alpha = 0.02;

%% 1. Read the Attacked Image and Perform DWT on It
%watermarked image

Iw   = imread(outputname);
Iw   = double(Iw);

[LLw, LHw, HLw, HHw] = dwt2(Iw, 'Haar');
[LLw2, LHw2, HLw2, HHw2] = dwt2(LLw, 'Haar');
[LLw3, LHw3, HLw3, HHw3] = dwt2(LLw2, 'Haar');

[LL, LH, HL, HH] = dwt2(Id, 'Haar');
[LL2, LH2, HL2, HH2] = dwt2(LL, 'Haar');
[LL3, LH3, HL3, HH3] = dwt2(LL2, 'Haar');

%% 2. Perform APDCBT on LL Sub-band
[Yw, Bw] = apdcbt(LLw3);
[Y, B] = apdcbt(LL3);

[dim1, dim2] = size(Y);

Y_re = reshape(Y, 1, dim1*dim2);
Y_sgn = sign(Y_re);
Y_mod = abs(Y_re);
[Y_sort,Yx] = sort(Y_mod,'descend');


Yw_re = reshape(Yw, 1, dim1*dim2);
Yw_sgn = sign(Yw_re);
Yw_mod = abs(Yw_re);
[Yw_sort,Ywx] = sort(Yw_mod,'descend');

%% 4. Watermark Extraction
wo = reshape(Io, 1, wat_size*wat_size);
w = zeros(1, wat_size*wat_size);

k = 2;
for j = 1:wat_size*wat_size
    m = Yx(k);
    %w(j) =uint8( (Yw_mod(m)/Y_mod(m) - 1)/alpha) ;
    w(j) = (Yw_mod(m)- Y_mod(m))/alpha ;
    if w(j)> 0
        w(j) = 1;
    else 
        w(j)= -1;
    end
    k = k+1;
end



%% Save the recovered watermarked
imwrite(uint8(w),'rec_wat.bmp');

%% Calculate similarity of original and recovered watermark

w_rec = rescale(w, 0,1);

count=0;
for i=1:wat_size*wat_size
    if w_rec(i)~= wo(i) 
        count = count +1;
    end
end
count

SIM = wo * w_rec' / sqrt( w_rec * w_rec' );

randWatermarks = round(rand(999,size(w,2)));
x = zeros(1,1000);

x(1) = SIM;  
for i = 1:999
    w_rand = randWatermarks(i,:);
    x(i+1) = w_rand * w_rec' / sqrt( w_rec * w_rec' );
end

x = abs(x);
x = sort(x, 'descend');
t = x(2);
T = t + 0.1*t;

%Decision
if SIM > T
    fprintf('Mark has been found. \nSIM = %f\n', SIM);
else
    fprintf('Mark has been lost. \nSIM = %f\n', SIM);
end

stop_time = cputime;
fprintf('Execution time = %0.5f sec\n',abs( start_time - stop_time));