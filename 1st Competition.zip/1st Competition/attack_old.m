
imgname = 'fish.bmp';
watname = 'lordprettywatermarker_fish.bmp';

detection = @detection_lordprettywatermarker;


binary_awgn(imgname, watname, detection);
binary_blur(imgname, watname, detection);
binary_jpeg(imgname, watname, detection);
binary_median(imgname, watname, detection);
binary_resize(imgname, watname, detection);