%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Course :  Multimedia Data Security
% Project:  Competition, 5th November
% Team   :  DryMark 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all; clear all;

alpha = 0.02;
%alpha = 0.02035;

%alpha = 0.019;

outputname = 'lenawat.bmp';
inputname = 'lena.bmp';


%% 1. Read the Images and Perform DWT on Carrier Image
I    = imread(inputname);
Id   = double(I);

wat_size = 32;

%Load watermark
W1 = load('drymark.mat').w;


%w = rescale(uint8(reshape(W1, 1, wat_size*wat_size)), -1,1);
%w = rescale(uint8(rand(32,32)),-1,1);

[LL, LH, HL, HH] = dwt2(Id, 'Haar');
[LL2, LH2, HL2, HH2] = dwt2(LL, 'Haar');
[LL3, LH3, HL3, HH3] = dwt2(LL2, 'Haar');

%% 2. Perform APDCBT on LL3 Sub-band
[Y, B] = apdcbt(LL3);

%% 3. Reshape Y

[dim1, dim2] = size(Y);

Y_re = reshape(Y, 1, dim1*dim2);

%% 4. Coefficient selection

Y_sgn = sign(Y_re);
Y_mod = abs(Y_re);
[Y_sort,Yx] = sort(Y_mod,'descend');


%% 5. Embedding

Yw_mod = Y_mod; 

k = 2;
for j = 1:wat_size*wat_size
    m = Yx(k);
    %Yw_mod(m) = Y_mod(m)*(1+alpha*w(j));
    Yw_mod(m) = Y_mod(m) + alpha*w(j);
    k = k+1;
end

%% 6. Restore the sign and go back to matrix representation using reshape

Y_new = Yw_mod.*Y_sgn;
Y_newi = reshape(Y_new,dim1,dim2);

%% 7. Inverse APDCBT

Y_wat = iapdcbt(Y_newi);

LLw3 = Y_wat;

%% 8. Perform IDWT to Get the Watermarked Image
LLw2 = idwt2(LLw3, LH3, HL3, HH3, 'Haar');
LLw = idwt2(LLw2, LH2, HL2, HH2, 'Haar');

Iw = idwt2(LLw, LH, HL, HH, 'Haar');

imshow(uint8(Iw));

%% 9. Save the watermarked image
imwrite(uint8(Iw),outputname);

%% 10. Calculate PSNR and WPSNR
q1 = PSNR(uint8(Id), uint8(Iw));
fprintf('PSNR = +%5.2f dB\n',q1);

q2 = WPSNR(uint8(Id), uint8(Iw));
fprintf('WPSNR = +%5.2f dB\n',q2);

%%
%detection_drymark('lena.bmp','lenawat.bmp','attacked')