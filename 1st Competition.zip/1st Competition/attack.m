

imname = 'cacti';
team = 'enigma';
imgname = strcat(imname, '.bmp');
watname = strcat(team, '_', imname, '.bmp');

% outputname = 'cacti_enigma.bmp';
% inputname = 'cacti.bmp';

detection = @detection_enigma;


% binary_awgn(imgname, watname, detection);
% binary_blur(imgname, watname, detection);
binary_jpeg(imgname, watname, detection);
% binary_median(imgname, watname, detection);
% binary_resize(imgname, watname, detection);
% binary_sharp(imgname, watname, detection);

param = 50
I = imread(watname);
Iatck = test_jpeg(I, param);
atckname = strcat('drymark_', team, '_', imgname);
imwrite(Iatck, atckname);

[det, wpsnr] = detection_enigma(imgname, watname, atckname)