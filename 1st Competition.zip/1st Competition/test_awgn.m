
function Iatt = test_awgn(Iw, noisePower, seed)


 % Seed random generator
 rng(seed, 'twister');

Iatt = imnoise(Iw,'gaussian',0,noisePower);

