function power = binary_sharp(original, watermarked, detection)

    minpower = 0;
    maxpower = 4;
    
    I = imread(watermarked);
    max = 0;
    maxi = 0;
    maxk = 0;
    eps = 0.01;
    for i=1:10
    
        while(abs(maxpower - minpower) > eps)
            k = (maxpower + minpower)/2;
            Iatck = test_sharpening(I, i, k);
            attacked = 'sharp_test.bmp';
            imwrite(Iatck, attacked);
            [contains, wpsnr_val] = detection(original, watermarked, attacked);
            delete(attacked);
            
            if contains == 1
                minpower = k;
            else
                maxpower = k;
            end
        end
        i
            wpsnr_val
        if wpsnr_val > max
            max = wpsnr_val;
            maxi = i;
            maxk = k;
        end
    end
    power = maxk;
        
    fprintf('Sharpening attack: Radius=%f, val=%f, WPSNR=%f\n', maxi, maxk, max);
end