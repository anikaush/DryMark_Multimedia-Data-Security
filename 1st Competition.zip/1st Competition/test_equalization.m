function Iatt = test_equalization(Iw,nPower)

Iatt = histeq(Iw,nPower);
