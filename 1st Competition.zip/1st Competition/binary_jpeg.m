function power = binary_jpeg(original, watermarked, detection)

    minpower = 0;
    maxpower = 100;
    wpsnrmax = 0;
    
    I = imread(watermarked);
    
    eps = 1;
    lastk = maxpower;
    while(abs(maxpower - minpower) > eps)
        k = (maxpower + minpower)/2;
        k = ceil(k);
        Iatck = test_jpeg(I, k);
        attacked = 'jpeg-temp.bmp';
        imwrite(Iatck, attacked);
        
        
        [contains, wpsnr_val] = detection(original, watermarked, attacked);
        delete(attacked);
        
        if contains == 1
            maxpower = k;
        else
            minpower = k;
            if wpsnrmax < wpsnr_val
                wpsnrmax = wpsnr_val;
                lastk = k;
            end
            
        end
    end
    power = lastk;
    
    fprintf('JPEG attack: power=%f, WPSNR=%f\n', power, wpsnr_val);
end