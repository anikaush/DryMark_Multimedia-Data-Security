function Iatt = test_median(Iw,na,nb)

Iatt = medfilt2(Iw,[na nb]);
