function power = binary_blur(original, watermarked, detection)

    minpower = 0;
    maxpower = 2;
    
    wpsnrmax = 0;
    
    I = imread(watermarked);
    
    eps = 0.0001;
    lastk = maxpower;
    while(abs(maxpower - minpower) >= eps)
        k = (maxpower + minpower)/2;
        Iatck = test_blur(I, k);
        attacked = 'blur-temp.bmp';
        imwrite(Iatck, attacked);
        [contains, wpsnr_val] = detection(original, watermarked, attacked);
        delete(attacked);
        
        if contains == 1
            minpower = k;
        else
            maxpower = k;
            if wpsnrmax < wpsnr_val
                wpsnrmax = wpsnr_val;
                lastk = k;
            end
        end
    end
    
    power = lastk;
    
    fprintf('BLUR attack: power=%f, WPSNR=%f\n', power, wpsnr_val);
end