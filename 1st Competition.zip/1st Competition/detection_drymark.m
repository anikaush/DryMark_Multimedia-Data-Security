%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Course :  Multimedia Data Security
% Project:  Competition, 5th November
% Team   :  DryMark 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Version 7

function [contains, wpsnr_val] = detection_drymark(original, watermarked, attacked) 

    wat_size = 32;
    %define watermark strength
    %alpha = 0.02035;
    alpha = 0.02;
    
    function [Y, V] = apdcbt(X)
       % Reference : Embedding Binary Image Watermark in DC Components of All
       % Phase Discrete Cosine Biorthogonal Transform
       % Author : Zabir Al Nazi
       % Email : zabiralnazi@codeassign.com

       [M, N, z] = size(X);

       X = double(X);
       Y = zeros(M,N);
       V = zeros(M,N);

       for m = 0:M-1
           for n = 0:N-1

               if (n == 0 )
                   V(m+1,n+1) = (N-m)/(N^2);
               else
                   V(m+1,n+1) = ((N-m)*cos((m*n*pi)/N) - ...
                       csc((n*pi)/N)*sin((m*n*pi)/N))/(N^2);
               end

           end
       end

       Y = V*X*V'; % without optimization



    end

    function wat_extracted = extraction(I, Iw)
         %% 1. Perform DWT on watermarked image

        Iw = double(Iw);
        Id = double(I);

        [LLw, LHw, HLw, HHw] = dwt2(Iw, 'Haar');
        [LLw2, LHw2, HLw2, HHw2] = dwt2(LLw, 'Haar');
        [LLw3, LHw3, HLw3, HHw3] = dwt2(LLw2, 'Haar');

        [LL, LH, HL, HH] = dwt2(Id, 'Haar');
        [LL2, LH2, HL2, HH2] = dwt2(LL, 'Haar');
        [LL3, LH3, HL3, HH3] = dwt2(LL2, 'Haar');

        %% 2. Perform APDCBT on LL3Sub-band
        [Yw, Bw] = apdcbt(LLw3);
        [Y, B] = apdcbt(LL3);

        [dim1, dim2] = size(Y);

        Y_re = reshape(Y, 1, dim1*dim2);
        Y_sgn = sign(Y_re);
        Y_mod = abs(Y_re);
        [Y_sort,Yx] = sort(Y_mod,'descend');


        Yw_re = reshape(Yw, 1, dim1*dim2);
        Yw_sgn = sign(Yw_re);
        Yw_mod = abs(Yw_re);
        [Yw_sort,Ywx] = sort(Yw_mod,'descend');

        %% 4. Watermark Extraction from watermarked image

        wat_extracted = zeros(1, wat_size*wat_size);

        k = 2;
        for j = 1:wat_size*wat_size
            m = Yx(k);
            wat_extracted(j) = (Yw_mod(m) - Y_mod(m))/(alpha*Y_mod(m));
            k = k+1;
            if wat_extracted(j)> 0
                wat_extracted(j) = 1;
            else 
                wat_extracted(j)= 0;
            end
        end
        
    end

    %original image
    Img    = imread(original,'bmp');

    %watermarked image
    Img_w    = imread(watermarked,'bmp');

    %attacked image
    Img_a    = imread(attacked,'bmp');

    %define threshold 
    T = 14.0483;
    
    %% Recover the watermarks
    wat_extracted = extraction(Img, Img_w);
    wat_attacked = extraction(Img, Img_a);

    %% Calculate similarity of extracted and attacked watermark
    w_ext = reshape(wat_extracted, 1, wat_size*wat_size);
    w_att = reshape(wat_attacked, 1, wat_size*wat_size);

    SIM = w_ext * w_att' / sqrt( w_att * w_att' );

    %Decision
    if SIM > T
        contains = 1;
    else
        contains = 0;
    end
    
    wpsnr_val = WPSNR(uint8(Img_a), uint8(Img_w));
    
    % TESTING PURPOSE - we will delete these comments before generating the p code
    % wo = load('drymark').w;
    % wo = reshape(wo, 1, 1024);
    % count = sum(abs(wo-w_ext)); % calculates how many bits differs from the original watermark

end
