function power = binary_median(original, watermarked, detection)

    wpsnrmax = 0;
    maxi = 0;
    maxj = 0;
    
    I = imread(watermarked);
    
    for i = 1:2:13
        for j = 1:2:13
            
            Iatck = test_median(I, i, j);
            attacked = 'median-temp.bmp';
            imwrite(Iatck, attacked);

            [contains, wpsnr_val] = detection(original, watermarked, attacked);
            delete(attacked);

            if contains == 0
                if wpsnrmax < wpsnr_val
                    wpsnrmax = wpsnr_val;
                    maxi = i;
                    maxj = j;
                end
            end
        end
    end
    
    fprintf('Median attack: i=%f, j=%f, WPSNR=%f\n', maxi, maxj, wpsnrmax);
end