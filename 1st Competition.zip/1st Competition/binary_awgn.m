function power = binary_awgn(original, watermarked, detection)

    minpower = 0;
    maxpower = 0.1;
    
    I = imread(watermarked);
    wpsnrmax = 0;
    eps = 0.0001;
    lastk = maxpower;
    while(abs(maxpower - minpower) >= eps)
        k = (maxpower + minpower)/2;
        Iatck = test_awgn(I, k, 123);
        attacked = 'awgn-temp.bmp';
        imwrite(Iatck, attacked);
       
        [contains, wpsnr_val] = detection(original, watermarked, attacked);
        delete(attacked);
        
        if contains == 1
            minpower = k;
        else
            maxpower = k;
            if wpsnrmax < wpsnr_val
                    wpsnrmax = wpsnr_val;
                    lastk = k;
            end
        end
    end
    power = lastk;
    
    fprintf('AWGN attack: power=%f, WPSNR=%f\n', power, wpsnrmax);
end