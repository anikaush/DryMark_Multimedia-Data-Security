im='dev_0010.jpg';
OutputMap = analyze(im);
imshow(OutputMap);