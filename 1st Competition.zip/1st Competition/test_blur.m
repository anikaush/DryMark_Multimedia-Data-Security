
function Iatt = test_blur(Iw, noisePower)

Iatt = imgaussfilt(Iw,noisePower);


